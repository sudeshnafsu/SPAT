C*==translate.spg  processed by SPAG 6.50Rc at 11:55 on 16 May 2019
      program TRANSLATE
      implicit none
      real cv,ddm15,dtime,rdum,tmax,tmin,dm15s
      integer iq,it,itt,ndm,nout,nq,nx
      integer MINP,MQ,MOUT,MDM
      parameter (MINP=30,MQ=3,MOUT=100,MDM=10)
      character*1 char
      real timeinp(MINP,MQ),timeout(MOUT),dm(MOUT,MQ),q(MQ),dm15(MQ)
      real f(MINP),t(MINP),fout(MOUT,2,MQ),foutv(MOUT)
      open (unit=1,file='Lbols.png.dat',form='formatted')
      open (unit=3,file='qtodm15.dat',form='formatted')
      open (unit=2,file='test1.out',form='formatted')
      open (unit=4,file='table.out',form='formatted')
C
C     Create time-grid
C
      tmin = -4.
      tmax = 20.
      nout = MOUT
      nq = MQ
      ndm = MDM
      dtime = (tmax-tmin)/FLOAT(nout+1)
      do 10 it = 1,MOUT
       timeout(it) = tmin + FLOAT(it)*dtime
   10 continue
C
C     Quick-fix for Q-dm15
C
      do 130 iq = 1,nq
       read (3,*) q(iq),dm15(iq)
  130 continue
C
C     Interpolate to new time
C
C
C     Read in table to interpolate
C
      do 60 iq = 1,nq
C      for L
       read (1,*) nx
       do 20 it = 1,nx
        read (1,*) rdum,f(it),t(it)
   20  continue
       call INTERPOL(t,f,nx,timeout,foutv,nout)
       do 30 it = 1,nout
        fout(it,1,iq) = foutv(it)
   30  continue
C      for E
       read (1,*) nx
       do 40 it = 1,nx
        read (1,*) rdum,f(it),t(it)
   40  continue
       call INTERPOL(t,f,nx,timeout,foutv,nout)
       do 50 it = 1,nout
        fout(it,2,iq) = foutv(it)
   50  continue
   60 continue
C
C     Differences in magnitudes
C
      do 80 iq = 1,nq
       do 70 it = 1,nout
        dm(it,iq) = (fout(it,2,iq)-fout(it,1,iq))/0.39794
        if ( ABS(dm(it,iq)).GT.1.E10 ) dm(it,iq) = 0.
   70  continue
   80 continue
C     translate to q=1.1
      do 100 iq = 2,nq
       do 90 it = 2,nout
        dm(it,iq) = dm(it,1) - dm(it,iq)
   90  continue
  100 continue
      do 110 it = 1,nout
       dm(it,1) = 0.
  110 continue
C
C     Write out the test
C
      write (2,'(3i4)') (iq,iq=1,3)
      do 120 it = 1,nout
       write (2,'(f10.2,2x,255e10.2)') timeout(it),(dm(it,iq),iq=1,3)
  120 continue
C
C     produce interpolated for new inbetween
C
      write (4,1000) rdum,(timeout(it),it=1,nout)
      write (4,1000) dm15(1),(dm(it,1),it=1,nout)
      do 150 iq = 2,nq
       ddm15 = (dm15(it)-dm15(it-1))/FLOAT(ndm+1)
       do 140 itt = 1,ndm
        cv = FLOAT(itt)/FLOAT(ndm)
        dm15s=cv*dm15(it-1)+(1.-cv)*dm15(it)
        write (4,1000)dm15s,((dm(it-1,iq)*cv+(1.-cv)*dm(it,iq)),it=1,
     &         nout)
  140  continue
  150 continue
 1000 format (f10.2,2x,255E10.3)
      end
C*==interpol.spg  processed by SPAG 6.50Rc at 11:55 on 16 May 2019
      subroutine INTERPOL(tin,fin,nx,tout,fout,nout)
      implicit none
C*** Start of declarations inserted by SPAG
      integer i,index,ISRFGE,nin
      real y0
C*** End of declarations inserted by SPAG
      integer MINP,MQ,MOUT,MDM
      parameter (MINP=30,MQ=3,MOUT=100,MDM=10)
      integer nx,nout
      real tin(MINP),fin(MINP),tout(MOUT),fout(MOUT)
C
C     interpolate values on grid
C
      do 10 i = 1,nout
       index = ISRFGE(nx-1,tin,1,tout(i))
       if ( index.GT.1 .AND. tout(i).LT.tin(nx) ) then
        call PARROT(tin,fin(1),index,MINP,nx,tout(i),y0,1)
        write (6,'(i5,6e12.2)') index,tin(i),tin(i-1),tout(i),y0
        fout(i) = y0
       else
        fout(i) = 1.E30
       endif
       if ( tout(nout).GT.tin(nin) ) fout(i) = 1.E30
   10 continue
      end
C*==parrot.spg  processed by SPAG 6.50Rc at 11:55 on 16 May 2019
      subroutine PARROT(x,y,j,ndim,n,x0,y0,k)
      implicit none
C*** Start of declarations inserted by SPAG
      real a,aa,alpha,alt,b,c,ca,cc,cw,cw2,d,d1,d3,dx,dy,fx,fy,p,p2,phi
      real q,q3,QR,r,rca,res,root,sa,save,sw,test,theta,w,wt1,wt2,x,x0,
     &     x1,x3,xa
      real xo,xp,xp2,y,y0,y1,y3,yp
      integer i,ierr,iline,is,j,j0,j1,j3,k,l,n,ndim,NST
C*** End of declarations inserted by SPAG
      integer MINP
      parameter (MINP=30,NST=MINP)
C
C     REAL VERSION
C
C PARROT INTERPOLATES BETWEEN A SET OF POINTS IN ARRAYS X AND Y. (THE X
C ARRAY MUST BE MONOTONIC, INCREASING OR DECREASING.)  THE CURVE PRODUCE
C BY PARROT FOLLOWS THE DATA VERY CLOSELY: POLYNOMIAL "WIGGLES" BETWEEN
C POINTS ARE ALMOST ENTIRELY ELIMINATED.  THE FIRST AND SECOND DERIVATIV
C ARE EVERYWHERE CONTINUOUS.
C PARROT FINDS ONE ROTATED PARABOLA PASSING THROUGH THE POINTS J-2, J-1,
C AND J, WITH VERTEX EXACTLY AT J-1, AND A SECOND PARABOLA PASSING THROU
C J-1, J, AND J+1, WITH VERTEX AT J, THEN DETERMINES THE Y VALUES
C CORRESPONDING TO X0 FOR EACH CURVE.  THE RETURNED VALUE Y0 IS THE
C WEIGHTED SUM OF THE Y VALUES ON THE TWO PARABOLAS, WITH THE WEIGHTS
C DETERMINED BY THE DISTANCE OF THE INTERPOLATED POINT FROM POINTS J AND
C J-1, RESPECTIVELY. (IN THE FIRST AND LAST INTERVALS, THE RESULT IS A
C WEIGHTED AVERAGE OF A PARABOLA AND A STRAIGHT LINE.)
C
C  INPUT PARAMETERS (UNCHANGED BY PARROT) :
C
C    X(I),Y(I) - ARRAYS OF KNOWN POINTS TO BE INTERPOLATED; X MONOTONIC.
C            N - LARGEST DEFINED INDEX OF X(I) AND Y(I)
C           X0 - POINT FOR WHICH INTERPOLATED VALUE IS TO BE RETURNED
C            J - X(J) AND X(J-1) MUST BRACKET X0
C            K - SET K.EQ.1 IF CALLING PARROT FOR THE FIRST TIME IN THIS
C                INTERVAL; SET K.NE.1 IF X,Y, AND J ARE THE SAME AS THE
C                PREVIOUS CALL TO PARROT (FOR THE SAME VALUE OF IS).
C                AS PARROT IS RELATIVELY SLOW, MOST EFFICIENT USE REQUIR
C                ORDERING X0 AND SETTING K.NE.1 WHENEVER POSSIBLE.
C          [IS - SETTING IS = 1, 2, OR 3 IN THE CALLING PROGRAM (WITH
C                COMMON/PAROT/IS) ALLOWS THREE DIFFERENT SETS OF
C                PARAMETERS TO BE REMEMBERED SIMULTANEOUSLY]
C
C  OUTPUT PARAMETERS :
C
C           Y0 - RETURNED VALUE CORRESPONDING TO X0
C         IERR - ERROR FLAG = 0 IF NO ERRORS; = 1 IF X0 IS OUTSIDE THE
C                INTERVAL BETWEEN X(1) AND X(N); = 2 IF X(I) ARE NOT
C                MONOTONIC; = 3 IF X0 IS OUTSIDE THE INTERVAL BETWEEN
C                X(J) AND X(J-1).  IF IERR = 1, Y0 IS A LINEAR
C                EXTRAPOLATION.  Y0 IS NOT SET FOR IERR > 1.
C
C
      common /PAROT / is
      common /SAV3  / cw(2,3),sw(2,3),a(2,3),b(2,3),fx(2,3),fy(2,3),
     & iline(2)
      dimension x(NST),y(NST),res(2)
C
C CHECK FOR ERROR CONDITIONS
      ierr = 0
      do 10 l = 2,n - 1
       if ( (x(l-1)-x(l))*(x(l)-x(l+1)).LE.0. ) then
        ierr = 2
        write (6,1000) ierr
        return
       endif
   10 continue
      if ( (x(n)-x0)*(x0-x(1)).LT.0. ) then
C
       ierr = 1
       write (6,1100) ierr
       y0 = y(1) + (y(1)-y(2))*(x0-x(1))/(x(1)-x(2))
       if ( (x0-x(n))*(x(n)-x(n-1)).GT.0. ) y0 = y(n) + (y(n)-y(n-1))
     &      *(x0-x(n))/(x(n)-x(n-1))
       return
      endif
      if ( (n-j)*(j-1).LT.0. ) go to 130
      if ( (x(j)-x0)*(x0-x(j-1)).LT.0. ) go to 130
C
      do 120 i = 1,2
       j0 = i + j - 2
       xo = x0 - x(j0)
       if ( k.EQ.1 ) then
C
C TRANSLATE COORDINATES TO VERTEX OF EACH FUTURE PARABOLA, WITH X1
C ALWAYS CHOSEN TO BE CLOSEST TO X0 (+ LINEAR EXTRAPOLATION PAST ENDS)
C (SINCE J0 IS EITHER J OR J-1, J1 IS CHOSEN TO BE THE OTHER)
        j1 = j - i + 1
        x1 = x(j1) - x(j0)
        y1 = y(j1) - y(j0)
        if ( j0.GT.1 ) then
         if ( j0.LT.n ) then
          j3 = j + 3*i - 5
          x3 = x(j3) - x(j0)
          y3 = y(j3) - y(j0)
          go to 20
         endif
         x3 = x(n) - x(n-1)
         y3 = y(n) - y(n-1)
         go to 20
        endif
        x3 = x(1) - x(2)
        y3 = y(1) - y(2)
   20   continue
        res(i) = 0.
        if ( y1.EQ.0. .AND. y3.EQ.0. ) then
         cw(i,is) = 1.
         sw(i,is) = 0.
         a(i,is) = 0.
         b(i,is) = 0.
         iline(i) = 0.
         go to 80
        endif
C SCALE X COORDINATES TO APPROXIMATELY SAME SIZE AS Y COORDINATES
        fx(i,is) = MAX(ABS(x3),ABS(x1))
        fy(i,is) = MAX(ABS(y3),ABS(y1))
        if ( fy(i,is).EQ.0. ) fy(i,is) = 1.
        x1 = x1/fx(i,is)
        x3 = x3/fx(i,is)
        xo = xo/fx(i,is)
        y1 = y1/fy(i,is)
        y3 = y3/fy(i,is)
C DETERMINE ANGLE OF ROTATION W SUCH THAT A PARABOLA OF THE FORM Y=A*X**
C PASSES THRU THE THREE POINTS (IF THETA IS THE ANGLE FROM THE ORIGIN
C AND (X1,Y1) TO THE NEW (ROTATED) Y AXIS; NEED TO SOLVE A CUBIC EQUATIO
C IN Y = TAN(THETA):  Y**3 + P*Y**2 + 2*R*CA*Y - R*SA = 0 ,  WHERE
C  P = CA*(1-R*CA)/SA, CA = COS(ALPHA), SA = SIN(ALPHA), AND ALPHA IS
C THE ANGLE BETWEEN THE LINES FROM THE ORIGIN TO (X1,Y1) AND (X3,Y3).
C IF Y=X-P/3, CAN GET EQUATION OF FORM X**3 + A*X + B = 0.
        d1 = x1*x1 + y1*y1
        d3 = x3*x3 + y3*y3
        r = SQRT(d3/d1)
        d = SQRT(d1*d3)
        ca = (x1*x3+y1*y3)/d
        sa = (x1*y3-x3*y1)/d
        if ( ABS(sa).LT..001 ) then
         theta = sa
         if ( ca.LT.0. ) theta = 3.1415927 - sa
         theta = theta/2.
         go to 70
        endif
        rca = r*ca
        p = ca*(1.-rca)/sa
        p2 = p*p
        q = 2.*rca - p2/3.
        r = 2.*(p2*p/27.-p*rca/3.) - r*sa
        q3 = q*q*q/27.
        root = .25*r*r + q3
        if ( root ) 50,40,30
       endif
C SKIP PARABOLA CALCULATIONS IF X AND Y POINTS ARE THE SAME AS LAST TIME
       xo = xo/fx(i,is)
       y1 = (y(j+1-i)-y(j0))/fy(i,is)
       go to 80
   30  continue
       root = SQRT(root)
       theta = ATAN(QR(-0.5*r+root)+QR(-0.5*r-root)-p/3.)
       go to 70
C EVALUATE 2 SOLUTIONS; FIND THETA (0<THETA<ALPHA)
   40  continue
       cc = QR(-r/2.)
       alpha = ATAN2(sa,ca)
       theta = ATAN(2.*cc-p/3.)
       alt = ATAN(-cc-p/3.)
       if ( alt*(alpha-alt).GT.theta*(alpha-theta) ) theta = alt
       go to 70
C EVALUATE 3 SOLUTIONS; FIND THETA (0<THETA<ALPHA)
   50  continue
       phi = COS(-r/2./SQRT(-q3))/3.
       cc = 2.*SQRT(-q/3.)
       alpha = ATAN2(sa,ca)
       save = -1.
       do 60 l = 1,3
        test = ATAN(cc*COS(phi+(l-1)*2.0943951)-p/3.)
        alt = test*(alpha-test)
        if ( alt.LT.save ) go to 60
        theta = test
        save = alt
   60  continue
   70  continue
       w = theta - ATAN2(x1,y1)
C SAVE COS AND SIN OF W, PLUS A AND B
       cw(i,is) = COS(w)
       sw(i,is) = SIN(w)
       xp = x1*cw(i,is) + y1*sw(i,is)
       yp = y1*cw(i,is) - x1*sw(i,is)
       cw2 = cw(i,is)*cw(i,is)
       xp2 = xp*xp
       c = 4.*sw(i,is)*yp
C NOTE C AND XP2 CAN NEVER BE SIMULTANEOUSLY ZERO, NOR XP2 AND YP,
C NOR YP AND CW2, NOR C AND CW2 (UNLESS X1=0, WHICH IS NOT LEGAL
C IN PARROT)
       if ( ABS(c).GT.1.E6*xp2*cw2 ) then
        a(i,is) = xp2/yp
        b(i,is) = xp2/c
        iline(i) = 1
        go to 80
       endif
       a(i,is) = yp/xp2
       b(i,is) = c/xp2
       iline(i) = 0
C
C CALCULATE RESULTING Y FOR THIS PARABOLA
   80  continue
       if ( x0.NE.x(j-1) ) then
        if ( x0.NE.x(j) ) then
C
         cw2 = cw(i,is)*cw(i,is)
         if ( iline(i).EQ.1 ) then
C ILINE = 1
          xa = xo*a(i,is)
          if ( ABS(xo).GT.1.E6*ABS(b(i,is))*cw2 ) go to 100
C XO IS ALWAYS NONZERO, THEREFORE, B, XP2, AND A MUST BE NONZERO;
C RETURN TO NORMAL CASE
          c = xo/b(i,is)
          aa = 1./a(i,is)
          go to 90
         endif
         c = b(i,is)*xo
         aa = a(i,is)
         if ( ABS(c).GT.1.E8*cw2 ) then
C XO VERY LARGE
          xa = xo/a(i,is)
          go to 100
         endif
   90    continue
         if ( ABS(c).LT..0001*cw2 ) then
C PARABOLA DEGENERATES TOWARDS A STRAIGHT HORIZONTAL LINE
          c = xo/cw(i,is)
          res(i) = c*(aa*c/cw(i,is)+sw(i,is))
          go to 110
         endif
         if ( ABS(sw(i,is)).LT..0001 ) then
C
C SPECIAL CASES 220,230,240,250,260 BELOW:
C ROTATION ANGLE CLOSE TO ZERO, BUT A NOT SMALL
          res(i) = xo*(aa*xo/(1.-c/2.)+sw(i,is))/cw(i,is)
          go to 110
         endif
C FIND INTERSECTION OF PARABOLA AND X0 LINE IN ROTATED COORDINATES;
C CALCULATE RESULT BACK IN UNROTATED COORDINATES.
         c = cw2 - c
         if ( c.LT.0. ) go to 130
         root = SQRT(c)
         c = xo*cw(i,is)/sw(i,is)
         d = 2.*aa*sw(i,is)*sw(i,is)
         res(i) = (cw(i,is)-root)/d - c
         alt = (cw(i,is)+root)/d - c
C CHOOSE ROOT IN INTERVAL [Y(J-1),Y(J)] (OR NEAREST TO THAT INTERVAL)
         if ( (y1-alt)*alt.GT.(y1-res(i))*res(i) ) res(i) = alt
         go to 110
        endif
        if ( i*k.EQ.1 ) go to 120
        y0 = y(j)
        return
       endif
       if ( i*k.EQ.1 ) go to 120
       y0 = y(j-1)
       return
C PARABOLA DEGENERATES TOWARDS A FOLDED VERTICAL LINE
  100  continue
       root = SQRT(-xa/sw(i,is))
       c = xo*cw(i,is)
       res(i) = (root-c)/sw(i,is)
       alt = (-root-c)/sw(i,is)
       if ( (y1-alt)*alt.GT.(y1-res(i))*res(i) ) res(i) = alt
C
  110  continue
       res(i) = res(i)*fy(i,is) + y(j0)
  120 continue
C
C WEIGHT TWO PARABOLAS ACCORDING TO DISTANCE FROM (J-1) AND (J)
      dx = x(j) - x0
      dy = y(j) - res(2)
      wt1 = SQRT(dx*dx+dy*dy)
      dx = x0 - x(j-1)
      dy = res(1) - y(j-1)
      wt2 = SQRT(dx*dx+dy*dy)
      y0 = (res(1)*wt1+res(2)*wt2)/(wt1+wt2)
      return
  130 continue
      ierr = 3
      write (6,1200) ierr
C        TYPE *,'X(I) NOT MONOTONIC'
 1000 format (' ',i5,' X(I) NOT MONOTONIC')
C        TYPE *,'LINEAR EXTRAPOLATION PAST ENDPOINTS'
 1100 format (' ',i5,' LINEAR EXTRAPOLATION PAST ENDPOINTS')
 1200 format (' ',i5,' X0 NOT BRACKETED BY X(J-1) AND X(J)')
C        TYPE *,'X0 NOT BRACKETED BY X(J-1) AND X(J)'
      end
C*==qr.spg  processed by SPAG 6.50Rc at 11:55 on 16 May 2019
      function QR(x)
      implicit none
C*** Start of declarations inserted by SPAG
      real QR,x
C*** End of declarations inserted by SPAG
      QR = 0.0
      if ( x.NE.0. ) QR = SIGN(EXP(LOG(ABS(x))/3.),x)
      end
C*==aa0001.spg  processed by SPAG 6.50Rc at 11:55 on 16 May 2019
      block data 
      implicit none
C*** Start of declarations inserted by SPAG
      real a,b,cw,fx,fy,sw
      integer iline,is
C*** End of declarations inserted by SPAG
      common /PAROT / is
      common /SAV3  / cw(2,3),sw(2,3),a(2,3),b(2,3),fx(2,3),fy(2,3),
     & iline(2)
      data fx,fy/6*1.,6*1./
      data is/1/
      end
C*==isrfge.spg  processed by SPAG 6.50Rc at 11:55 on 16 May 2019
      function ISRFGE(n,v,iv,t)
      implicit none
      integer n,iv,j,ISRFGE
      real v(*),t
      j = 1
      if ( iv.LT.0 ) j = 1 + (n-1)*(-iv)
      do 10 ISRFGE = 1,n
       if ( v(j).GE.t ) go to 99999
       j = j + iv
   10 continue
99999 continue
      end
