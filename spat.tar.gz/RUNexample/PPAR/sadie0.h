      character*5 rpath
      parameter(rpath='RDAT/')

      integer msne,malpha,nlarge,nmstep,nsig,nsrec,nsstep,ntstep
      integer itermax
      parameter(msne=275,malpha=msne**2/2-msne/2,nlarge=300,nmstep=15,
     & nsig=2,nsrec=245,nsstep=15,ntstep=15)
      parameter(itermax=10)

      real ftol,stand,xmax,xmin,ymax,ymin,zmax,zmin,tsigfac,ec
      parameter(ftol=1.E-5,stand=1.087,xmax=0.10,xmin=-0.10,ymax=3.0,
     & ymin=-3.0,zmax=0.05,zmin=-0.05,tsigfac=1.0,ec=0.09531)
