      integer header,nsig,msne,malpha,nstep,nlarge,ndmstep,ngrid
      character*5 inpath,spath,rsidpath,dpath,scalsigpath
      real tmin,tmax,ec,gaplim,gapsig,meiminp,meimaxp,gmax1,gmin1,
     & gmax2,gmin2,ftol,cofsummax,moffmin,moffmax,mzlim,mzratio
      integer mpoints,nrand,iseed,mgrid,elpoints,iflatness

      parameter(header=3,nsig=2,msne=275,malpha=(msne**2-msne)/2.0,
     & nstep=375,nlarge=300,ndmstep=90,ngrid=100)
      parameter(inpath="CDAT/",spath="SDAT/",rsidpath="RSDL/",dpath
     & = "DIFL/",scalsigpath="SSIG/")
      parameter(tmin=-20.0,tmax=70.0,ec=0.098,gaplim=3.5,gapsig=0.5,
     & meiminp=-5.0,meimaxp=15.0,
     & gmin1= -5.00   ,
     & gmax1=  5.00    , 
     & gmin2= -5.00    ,
     & gmax2=  5.00    ,
     & ftol=1.E-30,
     & cofsummax=3.0,
     & moffmin = -0.2,moffmax = 0.2,mzlim=0.1,mzratio=0.005)


      parameter(mpoints=50,nrand=1E8,iseed=23,mgrid=ngrid**nsig,
     & elpoints=100)
