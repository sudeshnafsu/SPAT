      real*8 ec,tmax,tmin
      character*5 inpath,outpath
      integer mrec,nstep,msne,fnlen,nlen,ierror
      real stand,tsigfac

c     NOTE: the length of the character variable [fnlen] MUST equal the 
c     character length of the variable [nlen] PLUS the character length of
c     the variables [outpath] and [inpath].  

      parameter(ec=1.01,tmax=50.0,tmin=-11.0)
      parameter(mrec=200,nstep=610,msne=275,fnlen=19,nlen=14,ierror=1)
      parameter(inpath='RDAT/',outpath='CDAT/')
c     Normalization of output to a standard s=0.92
      parameter (stand=1.087,tsigfac=1.0)
