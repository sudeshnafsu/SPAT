      integer mpair,msnia,mx,mfunc
c     nfact: boxes per unit
      parameter (mpair=1530,msnia=180,mx=1000,mfunc=2)
