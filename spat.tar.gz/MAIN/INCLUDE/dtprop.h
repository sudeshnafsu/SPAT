      real dtmax
      parameter(dtmax = 1.0)
 
      integer natr,ndtstep
      parameter(natr=191,ndtstep=20)
