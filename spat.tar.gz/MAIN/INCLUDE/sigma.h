      integer malpha,mrec,fnlen,nlen,msne
      character*5 inpath,outpath,gpath,dpath

c     NOTE: the length of the character variable [fnlen] MUST equal the 
c     character length of the variable [nlen] PLUS the character length of
c     the variables [outpath] and [inpath].  

      parameter(mrec=2000,malpha=38000,fnlen=25,nlen=20,msne=275)
      parameter(inpath='RSDL/',outpath='PDAT/',gpath='GDAT/',
     & dpath='DIFL/')
