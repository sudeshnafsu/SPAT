      integer msnia,np,nlen,mx,mrec,fnlen,len,mxnum
      character*5 inpath,outpath,LSSTpath,GAUSSpath
      parameter (msnia=50000,np=10,nlen=14,fnlen=19)
      parameter (len=8,mx=1000,mrec=200,mxnum=2000)
      parameter(inpath='RDAT/',outpath='LDAT/',LSSTpath='LSST/')
      parameter(GAUSSpath='GDAT/')
