      real erradd,gap,slack,tfmax,tfmin

      parameter(erradd=0.005,gap=2.5,slack=3.0,tfmax=15.0,tfmin=-4.0)

      integer mrec,natr,nlarge,msne,one

      parameter(mrec=200,natr=191,nlarge=300,msne=275,one=1)

      character*5 inpath,outpath
      character*10 echar
 
      parameter(inpath='RDAT/',outpath='RDAT/',echar='narcxxxxxx')
