      real*8 ec,tmax,tmin,tfmin,tfmax,slack,snorm
      integer malpha,mrec,msne,fnlen,nlen,knlen,nlarge,
     & iflatness,msne2,jnlen,rlen,dnlen,lnlen,lclen
      character*5 inpath,outpath,tempath,finpath

c     NOTE: the length of the character variable [fnlen] MUST equal the 
c     character length of the variable [nlen] PLUS the character length of
c     the variables [outpath] and [inpath].  

      parameter(ec=0.09531,tmax=80.0,tmin=-20.0,tfmin=-4.0,tfmax=15.0,
     & slack=3.0,snorm=1.000)
      parameter(mrec=200,msne=275,malpha=msne**2/2-msne/2,
     & fnlen=19,nlen=14,knlen=24,nlarge=300,jnlen=25,msne2=msne/2,
     & rlen=32,dnlen=16,lnlen=21,lclen=26)
      parameter(inpath='RDAT/',outpath='CDAT/',tempath='KDAT/',
     & finpath='QDAT/')
