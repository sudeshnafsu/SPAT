      integer msne
      parameter(msne=275)
