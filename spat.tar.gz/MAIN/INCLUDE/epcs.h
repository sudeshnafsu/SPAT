      integer malpha,msne,mrec,nstep

      character*5 scalsigpath

      parameter(msne=275,malpha=msne**2/2-msne/2,mrec=200,nstep=61)
      parameter(scalsigpath="ESCL/")
