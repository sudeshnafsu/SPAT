      integer nlarge
      parameter(nlarge=300)
