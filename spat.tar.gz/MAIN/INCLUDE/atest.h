      real*8 ec,tmax,tmin,dsmin_p,dsmax_p,dtmin_p,dtmax_p,chi2min,tfmin,
     & tfmax,qcon,slack,snorm,gaplim,sf1,sf2,hlevel,qlevel,kw,eps,
     & seglim,dmmin,dmmax,mwinmin,mwinmax,exten
      integer malpha,ieo,mrec,nstep,msne,fnlen,nlen,nlarge,nsstep,
     & ntstep,nsteptemp,ntemplate,nwinmin,nmstep,ntrace,itest1,itest2,
     & itertest,iter_max,ndmstep,alph2,natr,iflatness,srec,msne2
      character*5 inpath,outpath,tpath

c     NOTE: the length of the character variable [fnlen] MUST equal the 
c     character length of the variable [nlen] PLUS the character length of
c     the variables [outpath] and [inpath].  

      parameter(ec=0.09531,tmax=80.0,tmin=-20.0,dsmin_p=-0.05,
     & dsmax_p=0.05,
     & dtmin_p=-0.5,dtmax_p=0.5,chi2min=100.0,tfmin=-4.0,tfmax=15.0,
     & qcon=0.02,slack=3.0,snorm=1.000,gaplim=9.5,sf1=1.0,sf2=1.0,hlevel
     & = 1.75,qlevel=5.0,kw=1.00,seglim=2.0,dmmin=-0.2,dmmax=0.2,
     & mwinmin=-3.0,mwinmax=5.0,exten=2.5)
      parameter(ieo=2,mrec=200,nstep=375,msne=275,malpha=msne**2/2-
     & msne/2,fnlen=19,nlen=14,nlarge=300,nsstep=32,ntstep=32,
     & nsteptemp=191,ntemplate=24,nwinmin=7,nmstep=32,ntrace=500,
     & itest1=0,itest2=0,itertest=0,iter_max=7,ndmstep=100,natr=191,
     & srec=245,msne2=msne/2)
      parameter(inpath='RDAT/',outpath='CDAT/',tpath='TDAT/')
