      integer nlarge,nstep,msne,malpha,iflatness

      real*8 tmax,tmin,ec,ftol,tol          

c     character*5 INPATH


      parameter(nstep=61,msne=275,malpha=(msne**2-msne)/2.0,nlarge=300)

      parameter(tmin=-5.0,tmax=50.0,ec=1.01,ftol=1E-5,tol=1E-5)

c     parameter(INPATH='RSDL/')
