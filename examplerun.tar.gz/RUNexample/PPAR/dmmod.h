      integer ns0,nt0
      parameter(ns0=8,nt0=1000)
 
